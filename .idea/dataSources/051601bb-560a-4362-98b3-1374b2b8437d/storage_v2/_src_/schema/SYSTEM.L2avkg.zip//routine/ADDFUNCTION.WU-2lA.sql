create function addFunction (value1 NUMBER, value2 Number) RETURN NUMBER 
IS
    result number;

BEGIN
    result := value1 + value2;
    RETURN result;
END;
/

