create FUNCTION givePercentage(salary NUMBER) RETURN NUMBER IS
BEGIN
    RETURN (salary * 1.15);
END;
/

