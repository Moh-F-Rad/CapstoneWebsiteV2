create function spentByCus(
    cusID NUMBER
)
 RETURN NUMBER
 IS 
 
 totalSpent NUMBER;

 BEGIN
    select sum(total) into totalSpent
    from s_ord
    WHERE customer_id = cusID;

    RETURN totalSpent; 
END;
/

