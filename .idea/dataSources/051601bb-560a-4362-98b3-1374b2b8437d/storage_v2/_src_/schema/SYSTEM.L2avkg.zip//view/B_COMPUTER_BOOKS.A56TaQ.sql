create view B_COMPUTER_BOOKS as
SELECT      bb.isbn AS "ISBN",
            bb.title AS "B_TITLE",
            ba.lname||', '||ba.fname AS "A_NAME"
FROM        b_books bb
JOIN        b_bookauthor bba
ON          bb.isbn = bba.isbn
JOIN        b_author ba
ON          bba.authorid = ba.authorid
WHERE       category = 'COMPUTER'
/

