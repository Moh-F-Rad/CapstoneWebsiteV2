create view E_SALARY_TOTALS as
SELECT      job.department_code AS "DC",
            SUM(salary_amount) AS "TS" ,
            ROUND((SUM(salary_amount) / (
                SELECT      SUM(salary_amount) 
                FROM        e_salary_history
                WHERE       salary_end IS NULL)
                ) *100, 2) AS "PERC"
    FROM        e_job_history job
    JOIN        e_salary_history sal
            ON (job.employee_id = sal.employee_id)
    WHERE       salary_end IS NULL
            AND job_end IS NULL
    GROUP BY    department_code
/

