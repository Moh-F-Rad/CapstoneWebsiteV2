create view DETAILED_PRODUCT_INFO as
SELECT 
S_INVENTORY.PRODUCT_ID,
S_INVENTORY.WAREHOUSE_ID,
S_INVENTORY.AMOUNT_IN_STOCK,
S_WAREHOUSE.WHSE_CITY,
S_WAREHOUSE.WHSE_STATE,
S_WAREHOUSE.PHONE,
S_PRODUCT.PRODUCT_NAME
FROM s_inventory JOIN s_warehouse ON s_warehouse.warehouse_id = s_inventory.warehouse_id
JOIN s_product ON s_product.product_id = s_inventory.product_id
/

