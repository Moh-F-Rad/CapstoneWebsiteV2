create view CURRENT_SALARY as
SELECT employee_id, last_name, first_name, salary_start, salary_amount
FROM e_employees JOIN e_salary_history USING (employee_id)
WHERE salary_end IS NULL
/

