create function weekDay(aDay DATE) RETURN varchar2
IS
    resultDay varchar2(20);

BEGIN
    resultDay := to_char(aDay, 'Day');
    dbms_output.put_line(resultDay);
    if resultDay in ('Sunday', 'Saturday') then
    resultday := 'Weekend';
    else
    resultday := 'Weekday';
    END if;

    return resultDay;
END;
/

