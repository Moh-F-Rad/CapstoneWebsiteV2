create FUNCTION avgPrice (pub_id NUMBER) RETURN NUMBER
IS
    averagePrice NUMBER(5, 2);

BEGIN
    select AVG(retail) into averagePrice
    FROM b_books
    WHERE pubid = pub_id;

    RETURN averagePrice;
END;
/

