create view CUSTOMER_ORDERS as
SELECT S_CUSTOMER.CUSTOMER_ID,
            S_CUSTOMER.CUST_NAME,
            S_CUSTOMER.CUST_PHONE,
            S_CUSTOMER.CUST_ADDRESS,
            S_ORD.ORD_ID,
            S_ORD.TOTAL,
            S_EMP.EMPLOYEE_ID,
            S_EMP.EMP_LAST_NAME,
            S_EMP.EMP_FIRST_NAME,
            S_ITEM.QUANTITY,
            S_PRODUCT.PRODUCT_NAME,
            S_PRODUCT.PRODUCT_DESC
    FROM    s_customer 
    JOIN    s_ord
    ON      (s_ord.customer_id = s_customer.customer_id)
    JOIN    s_item
    ON      (s_ord.ord_id = s_item.ord_id)
    JOIN    s_product
    ON      (s_product.product_id = s_item.product_id)
    JOIN    s_emp
    ON      (s_emp.employee_id = s_ord.sales_rep_id)
/

