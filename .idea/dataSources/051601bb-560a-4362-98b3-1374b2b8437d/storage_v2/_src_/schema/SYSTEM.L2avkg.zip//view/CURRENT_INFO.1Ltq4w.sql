create view CURRENT_INFO as
SELECT  employee_id,last_name, first_name, job_start
FROM    e_employees JOIN e_job_history USING (employee_id)
/

